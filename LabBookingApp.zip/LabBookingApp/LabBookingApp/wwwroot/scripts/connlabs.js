﻿$.ajax({
    url: "http://localhost:5001/api/labs/getlabs",
        type: 'GET',
        dataType: 'json',
        success: function(data) {

        // CREATE DYNAMIC TABLE.
            var table = document.getElementById('connlab');
            var tbody = table.querySelector('tbody');

            var col = ["labId","labName","primaryLabOwner","secondaryLabOwner","labLocation","labCapabilities"];
                var index = 1;
                for (var i = 0; i < data.length; i++) {
                   tr = table.insertRow(-1);

                    for (var j = 0; j < col.length; j++) {

                        var tabCell = tr.insertCell(-1);

                        if (j === 0) {
                            tabCell.innerHTML = index;
                        }

                        else {

                            tabCell.innerHTML = data[i][col[j]];
                            //console.log(tabCell);
                        }
                    }
                    index = index + 1;
              // tbody.appendChild(tr)
            }


        },
        error:function(res){
            alert("Bad thing happend! " + res.statusText);
        }
});




$(document).ready(function(){
    $("#addlab").click(function(event){
    //event.preventDefault();
        debugger;
        var data = {
         "PrimaryLabOwner": $("#primaryowneremail").val(),
         "SecondaryLabOwner": $("#secondaryowneremail").val(),
         "LabLocation" : $("#lablocation").val(),
         "LabName" : $("#labname").val(),
         "LabCapabilities" : $("#labcapabilities").val(),
        };

        console.log(data);
    $.ajax({
        url:'http://localhost:5001/api/labs/addnewlab',
            type:'POST',
            data: JSON.stringify(data),
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success:function(res){
                alert("New Lab Has Been Added");
            },
            error:function(res){
                alert("Bad thing happend! " + res.statusText);
            }
        });
        
    });
  });
