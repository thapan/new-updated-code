﻿$(document).ready(function () {
    $("#loginBtn").click(function (event) {
        event.preventDefault();

        var data = {
            "Username": $("#username").val(),
            "Password": $("#password").val()
        };
        var userId = $("#username").val();
        console.log(data);
        $.ajax({
            url: 'http://MAA-8CG745065S:5001/api/login/UserLogin/',
            type: 'POST',
            data: JSON.stringify(data),
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (res) {
                alert("Your booking request has been sent to Lab Owner" + res);
                window.location.pathname = '/index.html';
                document.cookie = "username=" + userId;
            },
            error: function (res) {
                alert("wrong username/password");
            }
        });
        return false;
    });

});
