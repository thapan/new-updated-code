﻿var data;

$.ajax({
    url: "http://localhost:5001/api/labs/Bookedlabs",
        type: 'GET',
        dataType: 'json',
        success: function(data) {

        // CREATE DYNAMIC TABLE.
            var table = document.getElementById('tab');
            var tbody = table.querySelector('tbody');

            var col = ["userName","team","device","bookingPurpose","labName", "startTime","expireAt", "bookingStatus"];

            for (var i = 0; i < data.length; i++) {
               tr = table.insertRow(-1);

                for (var j = 0; j < col.length; j++) {

                    var tabCell = tr.insertCell(-1);
                    tabCell.innerHTML = data[i][col[j]];
                    if(col[j]=="bookingStatus"){
                        if(tabCell.innerHTML=="Pending"){
                            tabCell.className = 'pending';
                        }
                        else if(tabCell.innerHTML=="Approved"){
                                tabCell.className = 'approved';
                        }
                        else if(tabCell.innerHTML=="NotAvailable"){
                                tabCell.className = 'cancelled';
                        }     
                    }


                    if (col[j] === "startTime" || col[j] === "expireAt") {
                        var date = new Date(tabCell.innerHTML);
                        var year = date.getFullYear();
                        var month = date.getMonth() + 1;
                        var dt = date.getDate();
                        var hours = date.getUTCHours();
                        var minutes = date.getUTCMinutes();
                        if (dt < 10) {
                            dt = '0' + dt;
                        }
                        if (month < 10) {
                            month = '0' + month;
                        }
                        if (hours < 10) {
                            hours = '0' + hours;
                        }
                        if (minutes < 10) {
                            minutes = '0' + minutes;
                        }
                        tabCell.innerHTML = dt + '-' + month + '-' + year + ' ' + hours + ':' + minutes;
                      //  console.log(year + '-' + month + '-' + dt + ' ' + hours + ':' + minutes);
                    }
                    //console.log(tabCell);
                }
              // tbody.appendChild(tr)
            }


        },
        error:function(res){
            alert("Bad thing happend! " + res.statusText);
        }
});


$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});