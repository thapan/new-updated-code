﻿
var objJson = '';
$.ajax({
    url: "http://localhost:5001/api/Logs/GetLogs",
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            objJson = data;
            // CREATE DYNAMIC TABLE.
            var table = document.getElementById('logtab');
            var tbody = table.querySelector('tbody');

            var col = ["logTransactionType", "timeStamp", "requestLog","responseLog"];

          //  console.log(tabCell);
           // }
              //tbody.appendChild(tr)
        },


      //  },
        error:function(res){
            alert("Bad thing happend! " + res.statusText);
        }
});



$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#mytable1 tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


var current_page = 1;
var records_per_page = 10;

function prevPage()
{
    if (current_page > 1) {
        current_page--;
        changePage(current_page);
    }
}

function nextPage()
{
    if (current_page < numPages()) {
        current_page++;
        changePage(current_page);
    }
}
    
function changePage(page)
{
    var btn_next = document.getElementById("btn_next");
    var btn_prev = document.getElementById("btn_prev");
    var listing_table = document.getElementById("myTable1");
    var page_span = document.getElementById("page");
 
    // Validate page
    if (page < 1) page = 1;
    if (page > numPages()) page = numPages();

    listing_table.innerHTML = "";
    var col = ["logTransactionType", "timeStamp", "requestLog","responseLog"];

    for (var i = (page-1) * records_per_page; i < (page * records_per_page); i++) {
       tr = listing_table.insertRow(-1);

        for (var j = 0; j < col.length; j++) {
            var tabCell = tr.insertCell(-1);
            tabCell.innerHTML = objJson[i][col[j]];
        }
    }
    //for (var i = (page-1) * records_per_page; i < (page * records_per_page); i++) {
      //  listing_table.innerHTML += objJson[i].adName + "<br>";
    //}
    page_span.innerHTML = page;

    if (page == 1) {
        btn_prev.style.visibility = "hidden";
    } else {
        btn_prev.style.visibility = "visible";
    }

    if (page == numPages()) {
        btn_next.style.visibility = "hidden";
    } else {
        btn_next.style.visibility = "visible";
    }
}

function numPages()
{
    return Math.ceil(objJson.length / records_per_page);
}

window.onload = function() {
    changePage(1);
};