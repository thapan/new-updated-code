﻿
$.ajax({
    url: 'http://localhost:5001/api/labs/GetLabCapabilities',
    type: 'POST',
    dataType: 'json',
    contentType: "application/json; charset=utf-8",
    success: function (res) {
        console.log(res);
        $("#purpose").empty();

        if (res.length === 0 || res.length === null) {
            //$("#purpose").append('<option value="" disabled selected> No Lab Available </option>');
        }
        else {
            $("#purpose").append('<option value="" disabled selected> Select Purpose </option>');
        }


        for (var index = 0; index < res.length; index++) {
            console.log(res[index]);

            $("#purpose").append('<option>' + res[index] + '</option>');

        }
    },
    error: function (res) {
        alert("error");
    }
});

$.ajax({
    url: 'http://localhost:5001/api/labs/LogsInExcel',
    type: 'POST',
    dataType: 'json',
    contentType: "application/json; charset=utf-8",
    success: function (res) {
        console.log(res);
    },
    error: function (res) {
        alert("error");
    }
});

var userEmail = "";

function myFunction() {
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if ($("#emailAlias").val() == "" || reg.test($("#emailAlias").val()) === false) {
        alert("Please enter valid user email id");

    }
    else {
        userEmail = $("#emailAlias").val();
        document.getElementById('flashmessage').style.opacity = "0.0";
        document.getElementById("emailAlias").disabled = true;
    }

}

function validateEmailOnLabBooking(e) {

    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

    if ($("#emailAlias").val() === "") {
        alert("Please enter valid user email id");
        return false
    }

    else {
        userEmail = $("#emailAlias").val();
        document.getElementById('flashmessage').style.opacity = "0.0";
        document.getElementById("emailAlias").disabled = true;
    }

}

function getCookie(name) {
    var nameEQ = name + "=";
    //alert(document.cookie);
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1);
        if (c.indexOf(nameEQ) !== -1) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function getAbsolutetime() {

    var datetime = {
        "BookingTime": $("#time").val(),
        "BookingDate": $("#date").val()
    }

    var a = "T";
    var b = ":00Z";
    return $("#date").val().concat(a, $("#time").val(), b);

}


function diableOlddate() {

    $("#date").datepicker({ minDate: 0 });
}

function handleChange(e) {
    console.log("this")

    //TODO: Check other fields are ready to be sent
    if (validate()) {

        $("#labs").empty();

        //fetch labs
        var data = {
            "BookingId": null,
            "BookingPurpose": $('#purpose').val(),
            "BookingTime": getAbsolutetime(),
            "BookingDuration": $("#duration").val()
        }
        $.ajax({
            url: 'http://localhost:5001/api/labs/GetAvailableLabs',
            type: 'POST',
            data: JSON.stringify(data),
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function (res) {
                $("#labs").empty();

                if (res.length == 0 || res.length == null) {
                    $("#labs").append('<option value="" disabled selected> No Lab Available </option>');
                }
                else {
                    $("#labs").append('<option value="" disabled selected> Select Lab </option>');
                }


                for (var index = 0; index < res.length; index++) {
                    console.log(res[index].labName);

                    $("#labs").append('<option title="' + res[index].labCapabilities + '">' + res[index].labName + '</option>');

                }
            },

            error: function (res) {
                alert("All labs are booked for this time slot");

            }
        });

    }
}

function validate() {
    if ($('#date').val() !== "" && $('#time').val() != "") {
        return true;
    }
    return false;
}

$(document).ready(function () {

    $("#submitted").click(function (event) {
        event.preventDefault();

        var data = {
            "BookingId": null,
            "Team": $("#team").val(),
            "Device": $("#device").val(),
            "BookingPurpose": $("#purpose").val(),
            "LabName": $("#labs").val(),
            "BookingTime": getAbsolutetime(),
            "BookingDuration": $("#duration").val(),
            "UserName": userEmail,
            "BookingStatus": "Pending"
        };

        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if ($("#team").val() === "" || $("#purpose").val() === "" || $("#time").val() === "" || $("#date").val() === "" || getAbsolutetime() === "T:00Z") {
            alert("Please enter missing fields");

        }
        else if ($("#emailAlias").val() === "") {
            alert("Please enter user email id");
        }
        else if (userEmail == "") {
            alert('Please enter a valid user email id');

        }
        else {

            if ($("#labs").val() == null) {

                if (document.getElementById("labs").length > 0) {
                    alert("Please Select the available labs");
                }
                else {
                    alert("All Labs are booked for this time slot");
                }


            }
            else {
                document.getElementById('loader').style.display = "block";
                $.ajax({
                    url: 'http://localhost:5001/api/labs/BookLab/',
                    type: 'POST',
                    data: JSON.stringify(data),
                    dataType: 'json',
                    contentType: "application/json; charset=utf-8",
                    success: function (res) {

                        document.getElementById('loader').style.display = "none";

                        alert("Your booking request has been sent to Lab Owner");

                        //for successful booking Remove the entry of lab/setup from list

                        var select = document.getElementById('labs');
                        for (i = 0; i < select.length; i++) {
                            if (select.options[i].value === $("#labs").val()) {
                                select.remove(i);
                            }
                        }
                    },
                    error: function (res) {

                        document.getElementById('loader').style.display = "none";
                        alert("Please Select the Available Lab");

                    }

                });

            }
        }


    });

});                         