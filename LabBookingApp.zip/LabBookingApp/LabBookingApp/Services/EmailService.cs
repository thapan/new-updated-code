﻿using LabBookingApp.Models;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
//using System.Net.Mail;
using System.Threading.Tasks;

namespace LabBookingApp.Services
{
    public class EmailService:IEmailService
    {
        readonly IMailServerConfig _IMailServerConfig;
        public EmailService(IOptions<MailServerConfig> config)
        {
            _IMailServerConfig = config.Value;
        }
        public async void MailMethod(EmailConfig emailConfig)
        {
            var mimeMessage = new MimeMessage();
            mimeMessage.From.Add(new MailboxAddress
                                    (
                                     emailConfig.FromAddress
                                     ));
            mimeMessage.Sender = new MailboxAddress("neha.nehra92@gmail.com");
            mimeMessage.To.Add(new MailboxAddress
                                     (
                                     emailConfig.ToAddress
                                     ));
            if (emailConfig.ToCcAddress != null)
            {
                mimeMessage.Cc.Add(new MailboxAddress(emailConfig.ToCcAddress));

            }
            mimeMessage.Subject = emailConfig.Subject; //Subject  
            mimeMessage.Body = new TextPart("html")
            {
                Text = emailConfig.Content
            };
          
           try {
                using (var client = new SmtpClient())
                {
                    client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                    client.Connect(_IMailServerConfig.ServerName, _IMailServerConfig.PortNumber, true);
                 
                    client.Authenticate(
                    _IMailServerConfig.UserName,
                    _IMailServerConfig.Password
                    );
                    await client.SendAsync(mimeMessage);

                    await client.DisconnectAsync(true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("The email was not sent.");
                Console.WriteLine("Error message: " + ex.Message);
            }
        }

        public void SendEmail(EmailConfig emailConfig)
        {
            MailMethod(emailConfig);
        }
    }
}
