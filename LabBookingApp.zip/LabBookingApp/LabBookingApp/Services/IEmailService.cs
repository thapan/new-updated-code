﻿using LabBookingApp.Models;

namespace LabBookingApp.Services
{
    public interface IEmailService
    {
        void SendEmail(EmailConfig emailConfig);
    }
}