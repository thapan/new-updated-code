﻿using System;
using LabBookingApp.Models;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using System.Xml.Linq;

namespace LabBookingApp.Services
{
    public class LabService
    {
        private readonly IMongoCollection<Lab> _labs;
        private readonly IMongoCollection<BookedLabEntity> _bookedlabs;
        private readonly LogService _logService;

        public LabService(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("LabsDb"));
            IMongoDatabase database = client.GetDatabase("Labs");
            _labs = database.GetCollection<Lab>("LabsList");
            _bookedlabs = database.GetCollection<BookedLabEntity>("BookedLabs");
            _logService = new LogService(config);
        }

        public List<Lab> Get()
        {
            return _labs.Find(lab => true).ToList();
        }

        internal ActionResult<List<BookedLabEntity>> GetBookedLabs()
        {
            throw new NotImplementedException();
        }

        public Lab CreateLab(Lab lab)
        {
            var labCollection = Get();
            if (!(labCollection.Select(x => x.LabName).ToList().Contains(lab.LabName)))
            {
                var labsCollectioncount = labCollection.Count;
                lab.LabId = labCollection[labsCollectioncount-1].LabId + 1;
                var request = JsonConvert.SerializeObject(lab);
                _labs.InsertOne(lab);
                var response = JsonConvert.SerializeObject(lab);
                var transactionType = LogTransactionType.CreateLab;
                _logService.InsertLogEntity(request, response, transactionType);
            }
            return lab;
        }

        public List<BookedLabEntity> GetBookedLabList()
        {
            return _bookedlabs.Find(lab => true).ToList();
        }
        public BookedLabEntity Create(BookedLabEntity bookedLab, string bookingDuration)
        {
            var request = JsonConvert.SerializeObject(bookedLab);
            _bookedlabs.InsertOne(bookedLab);
            var response = JsonConvert.SerializeObject(bookedLab);
            var transactionType = LogTransactionType.BookLab;
            _logService.InsertLogEntity(request, response, transactionType);
            _logService.InsertBookedLabLogEntity(bookedLab, bookingDuration);
            return bookedLab;
        }

        public ClientLabEntity BookLab(ClientLabEntity bookLab)
        {
            var bookedlablist = GetBookedLabList();
            var bookedLab = new BookedLabEntity();
            var returnedBookLab = new ClientLabEntity();
            if (DateTime.TryParse(bookLab.BookingTime, out DateTime result) && double.TryParse(bookLab.BookingDuration, out double duration))
            {
                var timeinUtc = result.ToUniversalTime();
                bookedLab.ExpireAt = timeinUtc.AddHours(duration);
                bookedLab.LabName = bookLab.LabName;
                bookedLab.StartTime = timeinUtc;
                bookedLab.UserName = bookLab.UserName;
                bookedLab.Team = bookLab.Team;
                bookedLab.Device = bookLab.Device;
                bookedLab.BookingPurpose = bookLab.BookingPurpose;
                bookedLab.BookingStatus = bookLab.BookingStatus;

                var counter = 0;
                foreach(var _lab in bookedlablist)
                {
                   if( _lab.LabName == bookLab.LabName)
                    {
                        counter++;
                    }
                }
                if (counter == 0)
                {
                   var returedentity = Create(bookedLab, bookLab.BookingDuration);
                    bookLab.BookingId = returedentity.Id;
                }
                else if(counter >0)
                {
                    var commanCount = 0;
                    var commonLabEntity = bookedlablist.Where(x => x.LabName == bookLab.LabName).ToList();
                    foreach(var val in commonLabEntity)
                    {
                        if ((timeinUtc < val.StartTime && timeinUtc.AddHours(duration) > val.ExpireAt) || 
                        (timeinUtc == val.StartTime && timeinUtc.AddHours(duration) == val.ExpireAt) || 
                            (timeinUtc != val.StartTime && timeinUtc.AddHours(duration) == val.ExpireAt) || 
                        (timeinUtc == val.StartTime && timeinUtc.AddHours(duration) != val.ExpireAt) || 
                            (timeinUtc > val.StartTime && timeinUtc < val.ExpireAt) || 
                        (timeinUtc.AddHours(duration) > val.StartTime && timeinUtc.AddHours(duration) < val.ExpireAt))
                        {
                            commanCount++;
                        }
                    }
                    if(commanCount==0)
                    {
                        bookLab.BookingId = Create(bookedLab, bookLab.BookingDuration).Id;
                    }
                }
            }
            else
            {
                throw new Exception("Booking Time is not in correct format");
            }

            return bookLab;
        }
        public bool EvaluateLabs(ClientLabEntity bookLab, string masterLabName, string labCapabilities)
        {
            var bookedlablist = GetBookedLabList();
            var bookedLab = new BookedLabEntity();
            var returnedBookLab = new ClientLabEntity();
            if (DateTime.TryParse(bookLab.BookingTime, out DateTime result) && double.TryParse(bookLab.BookingDuration, out double duration))
            {
                var timeinUtc = result.ToUniversalTime();
                var endTimeinUtc = timeinUtc.AddHours(duration);

                var commanCount = 0;
                var commonLabEntity = bookedlablist.Where(x => x.LabName == masterLabName).ToList();
                if (commonLabEntity.Count == 0 && labCapabilities.Contains(bookLab.BookingPurpose))
                {
                    return true;
                }
                else
                {
                    foreach (var val in commonLabEntity)
                    {
                        if ((timeinUtc < val.StartTime && timeinUtc.AddHours(duration) > val.ExpireAt) ||
                        (timeinUtc == val.StartTime && endTimeinUtc == val.ExpireAt) ||
                        (timeinUtc != val.StartTime && endTimeinUtc == val.ExpireAt) ||
                        (timeinUtc == val.StartTime && endTimeinUtc != val.ExpireAt) ||
                        (timeinUtc > val.StartTime && timeinUtc < val.ExpireAt) ||
                        (endTimeinUtc > val.StartTime && endTimeinUtc < val.ExpireAt))
                        {
                            commanCount++;
                        }
                    }
                    if (commanCount == 0)
                    {
                        if (labCapabilities.Contains(bookLab.BookingPurpose))
                            return true;
                        else
                            return false;

                    }
                    else
                        return false;
                }
            }
            else
            {
                throw new Exception("Booking Time is not in correct format");
            }
        }
        public List<Lab> GetAvailableLabs(ClientLabEntity clientLabEntity)
        {
            var allLabsList = Get();
            var request = JsonConvert.SerializeObject(clientLabEntity);
            var availableList = new List<Lab>();
            foreach (var l in allLabsList)
            {
                if (EvaluateLabs(clientLabEntity, l.LabName, l.LabCapabilities))
                {
                    availableList.Add(l);
                }
            }

            var response = JsonConvert.SerializeObject(availableList);
            var transactionType = LogTransactionType.GetAvailableLabs;
            _logService.InsertLogEntity(request, response, transactionType);
            return availableList;
        }

        public string GetPrimaryLabOwnerId(string labName)
        {
            var allLabsList = Get();
            var availableList = new List<Lab>();
            foreach (var l in allLabsList)
            {
                if (l.LabName == labName)
                {
                    return l.PrimaryLabOwner;
                }
                    
            }

            return null;
        }

        public string GetSecondaryLabOwnerId(string labName)
        {
            var allLabsList = Get();
            var availableList = new List<Lab>();
            foreach (var l in allLabsList)
            {
                if (l.LabName == labName)
                {
                    return l.SecondaryLabOwner;
                }

            }

            return null;
        }

        public List<BookedLabEntity> ChangeLabStatus(string response, string bookingId)
        {
            FilterDefinition<BookedLabEntity> filter = Builders<BookedLabEntity>.Filter.Eq("Id", bookingId);
            UpdateDefinition<BookedLabEntity> update = Builders<BookedLabEntity>.Update.Set("bookingStatus", response);
            var result = _bookedlabs.UpdateOne(filter, update);
            var res = _bookedlabs.Find(filter).ToList();
            _logService.UpdateLabStatus(response, bookingId);
            return res;
        }


        public List<string> GetLabCapabilities()
        {
            var labCollection = Get();
            List<string> labCapabilities = new List<string>();
            foreach (var lab in labCollection)
            {
                var capability = lab.LabCapabilities.Split(',');
                for (int index = 0; index < capability.Length; index++)
                {
                    if (!labCapabilities.Contains(capability[index]))
                    {
                        labCapabilities.Add(capability[index]);
                    }
                }
            }
            return labCapabilities;
        }


    }
}