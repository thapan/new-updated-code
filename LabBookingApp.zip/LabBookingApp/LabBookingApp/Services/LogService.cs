﻿using System;
using LabBookingApp.Models;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using System.Text;
using System.Diagnostics;
using Microsoft.IdentityModel.Protocols;
using System.IO;
using System.Reflection;

namespace LabBookingApp.Services
{
    public enum LogTransactionType
    {
        GetLabs,
        CreateLab,
        BookLab,
        GetAvailableLabs
    }
    public class LogService
    {
        private readonly IMongoCollection<LogEntity> _log;
        private readonly IMongoCollection<BookedLabLogs> _bookingLog;
        private readonly IMongoCollection<BsonDocument> _bookingLogBSON;


        public LogService(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("LabsDb"));
            IMongoDatabase database = client.GetDatabase("Labs");
            _log = database.GetCollection<LogEntity>("LabBookingAppLogs");
            _bookingLog = database.GetCollection<BookedLabLogs>("BookedLabLogs");
            _bookingLogBSON = database.GetCollection<BsonDocument>("BookedLabLogs");

        }

        public void InsertLogEntity(string request, string response, LogTransactionType logTransactoionType)
        {
            var logEntity = new LogEntity();
            logEntity.RequestLog = request;
            logEntity.ResponseLog = response;
            logEntity.LogTransactionType = logTransactoionType.ToString();
            logEntity.TimeStamp = DateTime.Now;
            _log.InsertOne(logEntity);

        }

        public void InsertBookedLabLogEntity(BookedLabEntity bookLab, string bookingDuration)
        {
            var bookedlabLog = new BookedLabLogs();
            bookedlabLog.LabName = bookLab.LabName;
            bookedlabLog.StartTime = bookLab.StartTime;
            bookedlabLog.ExpireAt = bookLab.ExpireAt;
            bookedlabLog.BookingDuration = bookingDuration;
            bookedlabLog.UserName = bookLab.UserName;
            bookedlabLog.Team = bookLab.Team;
            bookedlabLog.Device = bookLab.Device;
            bookedlabLog.BookingPurpose = bookLab.BookingPurpose;
            bookedlabLog.BookingStatus = bookLab.BookingStatus;
            _bookingLog.InsertOne(bookedlabLog);
        }

        public List<LogEntity> Get()
        {
            return _log.Find(log => true).ToList();
        }
        public static HashSet<string> DictionaryFromType(object atype)
        {
            if (atype == null) return new HashSet<string>();
            Type t = atype.GetType();
            PropertyInfo[] props = t.GetProperties();
            HashSet<string> dict = new HashSet<string>();
            foreach (PropertyInfo prp in props)
            {
                dict.Add(prp.Name);
            }
            return dict;
        }
        public void ExportLogs()
        {
            try
            {
                HashSet<string> fields = new HashSet<string>();
                var result = _bookingLog.Find(lab => true);

                // Populate fields with all unique fields, see below for examples how.
                BookedLabLogs log = new BookedLabLogs();
                var csv = new StringBuilder();
                fields = DictionaryFromType(log);
                string headerLine = string.Join(",", fields).Replace("StartTime", "Booking Date").Replace("ExpireAt", "Booking Time");
                csv.AppendLine(headerLine);

                foreach (var element in result.ToListAsync().Result)
                {
                    string line = null;
                    foreach (var field in fields)
                    {
                        var value = "";
                        if (field == "Id")
                        {
                            value = element.Id.ToString();
                        }
                        else if (field == "UserName")
                        {
                            value = element.UserName.ToString();
                        }
                        else if (field == "LabName")
                        {
                            value = element.LabName.ToString();
                        }
                        else if (field == "StartTime")
                        {
                            value = element.StartTime.ToShortDateString().ToString();
                        }
                        else if (field == "ExpireAt")
                        {
                            value = element.StartTime.ToShortTimeString().ToString();
                        }
                        else if (field == "BookingDuration")
                        {
                            value = element.BookingDuration.ToString();
                        }
                        else if (field == "Team")
                        {
                            value = element.Team.ToString();
                        }
                        else if (field == "Device")
                        {
                            value = element.Device.ToString();
                        }
                        else if (field == "BookingPurpose")
                        {
                            value = element.BookingPurpose.ToString();
                        }
                        else if (field == "BookingStatus")
                        {
                            value = element.BookingStatus.ToString();
                        }
                        line = line + value.ToString();
                        
                        line = line + ",";
                    }
                    csv.AppendLine(line);
                }
                File.WriteAllText("C:/Users/nnehra/exportdetails.csv", csv.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.InnerException);
            }

        }

        public void UpdateLabStatus(string response, string bookingId)
        {
            FilterDefinition<BookedLabLogs> filter = Builders<BookedLabLogs>.Filter.Eq("Id", bookingId);
            UpdateDefinition<BookedLabLogs> update = Builders<BookedLabLogs>.Update.Set("bookingStatus", response);
           _bookingLog.UpdateOne(filter, update);
        }
    }
}
