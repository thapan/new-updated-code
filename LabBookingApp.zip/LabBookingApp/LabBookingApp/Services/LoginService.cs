﻿using LabBookingApp.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LabBookingApp.Services
{
    public class LoginService : ILogin
    {
        private readonly IMongoCollection<User> _user;
        private readonly LogService _logService;

        public LoginService(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("LabsDb"));
            IMongoDatabase database = client.GetDatabase("Labs");
            _user = database.GetCollection<User>("User");
            _logService = new LogService(config);
        }

        public List<User> Get()
        {
            return _user.Find(user => true).ToList();
        }

        public User UserLogin(User user)
        {
            var userCollection = Get();
            foreach (var _user in userCollection)
            {
                if (_user.Username == user.Username && _user.Password == user.Password)
                {
                    return _user;
                }
            }
            return user;
        }

        public User UserRegisteration(User user)
        {
            var userCollection = Get();
            if (!(userCollection.Select(x => x.Username).ToList().Contains(user.Username)))
            {
                var userCollectioncount = userCollection.Count;
                user.UserId = userCollectioncount + 1;
                var request = JsonConvert.SerializeObject(user);
                _user.InsertOne(user);
                var response = JsonConvert.SerializeObject(user);
                var transactionType = LogTransactionType.CreateLab;
                _logService.InsertLogEntity(request, response, transactionType);
            }
            return user;
        }
    }
}
