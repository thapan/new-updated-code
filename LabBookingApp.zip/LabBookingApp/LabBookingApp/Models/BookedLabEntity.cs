﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace LabBookingApp.Models
{
    public class BookedLabEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("UserName")]
        public string UserName { get; set; }

        [BsonElement("LabName")]
        public string LabName { get; set; }

        [BsonElement("StartTime")]
        public DateTime StartTime { get; set; }

        [BsonElement("expireAt")]
        public DateTime ExpireAt { get; set; }

        [BsonElement("team")]
        public string Team { get; set; }

        [BsonElement("device")]
        public string Device { get; set; }

        [BsonElement("bookingPurpose")]
        public string BookingPurpose { get; set; }

        [BsonElement("bookingStatus")]
        public string BookingStatus { get; set; }

        public static explicit operator BookedLabEntity(List<BookedLabEntity> v)
        {
            throw new NotImplementedException();
        }
    }
}
