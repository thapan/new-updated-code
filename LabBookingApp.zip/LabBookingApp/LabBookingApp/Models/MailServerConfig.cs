﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LabBookingApp.Models
{
    public class MailServerConfig:IMailServerConfig
    {
        public string ServerName { get; set; }
        public int PortNumber { get; set; }
        public bool SMTPAuth { get; set; }
        public string UserName { get; set; }

        public string Password { get; set; }
    }

    public interface IMailServerConfig
    {
        string ServerName { get; set; }
        bool SMTPAuth { get; set; }
        int PortNumber { get; set; }

        string UserName { get; set; }

        string Password { get; set; }
    }
}
