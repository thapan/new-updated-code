﻿using System;
using Newtonsoft.Json;

namespace LabBookingApp.Models
{
    public class ClientLabEntity
    {
        [JsonProperty]
        public string BookingId { get; set; }
        [JsonProperty]
        public string LabName { get; set; }
        [JsonProperty]
        public string BookingTime { get; set; }
        [JsonProperty]
        public string BookingDuration { get; set; }
        [JsonProperty]
        public string UserName{ get; set; }
        [JsonProperty]
        public string Team { get; set; }
        [JsonProperty]
        public string Device { get; set; }
        [JsonProperty]
        public string BookingPurpose { get; set; }
        [JsonProperty]
        public string BookingStatus { get; set; }

    }
}
