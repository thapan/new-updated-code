﻿using System;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LabBookingApp.Models

{
    public class LogEntity
    { 
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("RequestLog")]
        public string RequestLog { get; set; }

        [BsonElement("ResponseLog")]
        public string ResponseLog { get; set; }

        [BsonElement("LogTransactionType")]
        public string LogTransactionType { get; set; }

        [BsonElement("TimeStamp")]
        public DateTime TimeStamp { get; set; }
    }
}

