﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LabBookingApp.Models;
using LabBookingApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace LabBookingApp.Controllers
{
    [Route("api/[controller]/[action]")]

    public class LogsController : Controller
    {
        private readonly LogService _logService;
        public LogsController(LogService logService)
        {
            _logService = logService;
        }

        // GET api/values
        [ActionName("GetLogs")]
        [HttpGet]
        public ActionResult<List<LogEntity>> Get()
        {
            return _logService.Get();
        }

    }
}
