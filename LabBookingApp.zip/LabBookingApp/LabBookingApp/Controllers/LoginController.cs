﻿using LabBookingApp.Models;
using LabBookingApp.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LabBookingApp.Controllers
{
    [Route("api/[controller]/[action]")]
    public class LoginController : Controller
    {
        private readonly LoginService _loginService;
        public LoginController(LoginService loginService)
        {
            _loginService = loginService;
        }

        [ActionName("UserRegisteration")]
        [HttpPost]
        public ActionResult<User> UserRegisteration([FromBody]User user)
        {
            var newUser = _loginService.UserRegisteration(user);
            if (newUser.Id == null)
                return Ok("UserName already exists in database");
            else
                return newUser;
        }

        [ActionName("UserLogin")]
        [HttpPost]
        public ActionResult<User> UserLogin([FromBody]User user)
        {
            var newUser = _loginService.UserLogin(user);
            if (newUser.Id == null)
                return Ok("Incorrect username/password");
            else
                return newUser;
        }
    }
}
