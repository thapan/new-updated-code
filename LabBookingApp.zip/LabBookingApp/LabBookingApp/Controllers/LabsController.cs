﻿using LabBookingApp.Models;
using LabBookingApp.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LabBookingApp.Controllers
{
    [Route("api/[controller]/[action]")]
    public class LabsController : Controller
    {
        private readonly EmailService _emailService;
        private readonly LabService _labService;
        private readonly LogService _logService;
        private IHostingEnvironment _env;

        public LabsController(LabService labService, LogService logService, EmailService emailService, IHostingEnvironment env)
        {
            _labService = labService;
            _logService = logService;
            _emailService = emailService;
            _env = env;
        }

        // GET: api/values
        [ActionName("GetLabs")]
        [HttpGet]
        public ActionResult<List<Lab>> Get()
        {
            return _labService.Get();
        }

        [ActionName("BookedLabs")]
        [HttpGet]
        public ActionResult<List<BookedLabEntity>> GetBookedLabList()
        {
            return _labService.GetBookedLabList();
        }
       
        // POST api/values
        [ActionName("labApproval")]
        [HttpGet]
        public string labApproval(string response, string bookingId, string username, string labOwner)
        {
           var result = _labService.ChangeLabStatus(response, bookingId);
            if (result != null)
            {
                EmailConfigurations(result, username, labOwner);
            }
            return "Status updated successfully";
        }

        [ActionName("AddNewLab")]
        [HttpPost]
        public ActionResult<Lab> AddNewLab([FromBody]Lab lab)
        {

            var newLab= _labService.CreateLab(lab);
            if (newLab.Id == null)
                return Ok("Same Lab Name already exists in database");
            else
                return newLab;
        }

        [ActionName("BookLab")]
        [HttpPost]
        public ActionResult<ClientLabEntity> Post([FromBody]ClientLabEntity bookLab)
        {
            var clientLab = _labService.BookLab(bookLab);
            var primarylabOwner = _labService.GetPrimaryLabOwnerId(clientLab.LabName);
            var secondarylabOwner = _labService.GetSecondaryLabOwnerId(clientLab.LabName);
            if (clientLab.BookingId == null)
            {
                return Ok("Lab is booked for this duration");
            }
            else
            {
                string body = string.Empty;
                //using streamreader for reading my htmltemplate   
                var webRoot = _env.WebRootPath;
                var file = System.IO.Path.Combine(webRoot, "email.html");
                body = System.IO.File.ReadAllText(file);
                //CultureInfo culture = new CultureInfo("en-IN");
                DateTime startDateTime = Convert.ToDateTime(bookLab.BookingTime);

                var bodyForPrimaryOwner = body.Replace("$username", bookLab.UserName)
                       .Replace("$team", bookLab.Team)
                       .Replace("$device", bookLab.Device)
                       .Replace("$bookingPurpose", bookLab.BookingPurpose)
                       .Replace("$labName", bookLab.LabName)
                       .Replace("$startTime", startDateTime.ToUniversalTime().ToString())
                       .Replace("$duration", bookLab.BookingDuration)
                       .Replace("$id", clientLab.BookingId)
                       .Replace("$status", clientLab.BookingStatus)
                       .Replace("$labOwner", primarylabOwner);

                var bodyForSecondaryOwner = body.Replace("$username", bookLab.UserName)
                       .Replace("$team", bookLab.Team)
                       .Replace("$device", bookLab.Device)
                       .Replace("$bookingPurpose", bookLab.BookingPurpose)
                       .Replace("$labName", bookLab.LabName)
                       .Replace("$startTime", startDateTime.ToUniversalTime().ToString())
                       .Replace("$duration", bookLab.BookingDuration)
                       .Replace("$id", clientLab.BookingId)
                       .Replace("$status", clientLab.BookingStatus)
                       .Replace("$labOwner", secondarylabOwner);


                EmailConfig configprimaryowner = new EmailConfig()
                {
                    FromAddress = bookLab.UserName,
                    FromAddressTitle = "Lab Booking Tool",
                    Content = bodyForPrimaryOwner,
                    Subject = "Lab Booking Request",
                    ToAddress = primarylabOwner,   //primary lab owner
                    ToAddressTitle = "ToAddressTitle"

                };
               // _emailService.SendEmail(configprimaryowner);

                EmailConfig configsecondaryowner = new EmailConfig()
                {
                    FromAddress = bookLab.UserName,
                    FromAddressTitle = "Lab Booking Tool",
                    Content = bodyForSecondaryOwner,
                    Subject = "Lab Booking Request",
                    ToAddress = secondarylabOwner,   //secondary lab owner
                    ToAddressTitle = "ToAddressTitle"

                };
               // _emailService.SendEmail(configsecondaryowner);
            }
            return clientLab;
        }

        [ActionName("GetAvailableLabs")]
        [HttpPost]
        public ActionResult<List<Lab>> GetAvailableLabs([FromBody]ClientLabEntity bookLab)
        {
            var labsList = _labService.GetAvailableLabs(bookLab);
            if (labsList.Count == 0)
            {
                return Ok("All labs are booked for this duration");
            }
            return labsList;
        }


        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        public void EmailConfigurations([FromBody]List<BookedLabEntity> response, string username, string labOwner)
        {
            var primarylabOwner = _labService.GetPrimaryLabOwnerId(response.FirstOrDefault().LabName);
            var secondarylabOwner = _labService.GetSecondaryLabOwnerId(response.FirstOrDefault().LabName);

            string address = labOwner;

            var ccAddress = labOwner == primarylabOwner ? secondarylabOwner : primarylabOwner;

            string body = string.Empty;
            //using streamreader for reading my htmltemplate   
            var webRoot = _env.WebRootPath;
            var file = System.IO.Path.Combine(webRoot, "responseEmail.html");
            body = System.IO.File.ReadAllText(file);
            //CultureInfo culture = new CultureInfo("en-IN");
            DateTime startDateTime = Convert.ToDateTime(response.FirstOrDefault().StartTime);
            DateTime endDateTime = Convert.ToDateTime(response.FirstOrDefault().ExpireAt);

            body = body.Replace("$username", response.FirstOrDefault().UserName)
                   .Replace("$team", response.FirstOrDefault().Team)
                   .Replace("$device", response.FirstOrDefault().Device)
                   .Replace("$bookingPurpose", response.FirstOrDefault().BookingPurpose)
                   .Replace("$labName", response.FirstOrDefault().LabName)
                   .Replace("$startTime", startDateTime.ToUniversalTime().ToString())
                   .Replace("$endTime", endDateTime.ToUniversalTime().ToString())
                   .Replace("$id", response.FirstOrDefault().Id)
                   .Replace("$status", response.FirstOrDefault().BookingStatus);

            string fromaddresstitle = "labbookingtool@amazon.com";
            EmailConfig config = new EmailConfig()
            {
                FromAddress = address,
                FromAddressTitle = fromaddresstitle,
                Content = body,
                Subject = "Lab Booking Status - " + response.FirstOrDefault().BookingStatus + " by " + labOwner,
                ToCcAddress = ccAddress,
                ToAddress = username,
                ToAddressTitle = "Lab Booking Tool"

            };
            _emailService.SendEmail(config);


        }

        public List<string> GetLabCapabilities()
        {
            var labCapabilities = _labService.GetLabCapabilities();
            return labCapabilities;
        }

        public void LogsInExcel()
        {
            _logService.ExportLogs();
        }
    }
}

